function [vals, table, relVals] = robustRangeTriple( model, groups, angPerHalfCircle, normBoundary, singleBoundary, maxIter, relative )
%ROBUSTRANGETRIPLE Calculates the robust coefficient ranges of the three given coefficient groups.
% Computes the robust polyhedron of the given coefficients. A robust extreme, which forms the
% vertices of a robust polyhedron, is the maximum / minimum coefficient value for which the optimal solution
% of the FBA problem subject to the modified coefficients suffices the following conditions:
%	norm(v_nom - v_sol) <= normBoundary  and  abs(v_nom - v_sol) <= singleBoundary
%
% See getRobustExtremeConstrainedFlux for a description of the method used.
%
% This method uses spherical coordinates two create a grid on the unit sphere. The robust extreme 
% is computed for each direction in the three groups specified by the grid points.
% The parameter angPerHalfCircle gives the amount of steps used to partition a 180 degree angle.
% So there are angPerHalfCircle * (angPerHalfCircle - 1) * 2 grid points (leaving one out to avoid doubling).
%
% Note: Using spherical coordinates to create the grid (that is partitioning the theta and phi angles)
%	does not yield a uniform grid. This method leads to a concentration of the grid points at the poles.
%
% Parameters:
%	- model: Model.
%	- groups: Cell array with two groups. See MCGroups for hints.
%	- angPerHalfCircle: Count of partitions of a 180 degree angle.
%	- normBoundary: Upper bound on the solution deviation in the norm.
%	- singleBoundary: Upper bound on the absolute flux vector component deviation.
%	- maxIter: Maximum number of iterations. See getRobustExtremeConstrainedFlux for hints.
%	- relative: Set to true to treat the parameters normBoundary and singleBoundary as percentage of
%		the nominal values. Defaults to false.
%
% Returns:
%	- vals: A matrix in which each line is a ray cast in the direction of the i-th angle in the
%		angles vector. The columns are (in this order): 
%		theta in rad, phi in rad, absolute coefficient values, objective function value
%	- table: A table (cell array) of the matrix vals with headings.
%	- relVals: The same as vals except that the middle columns contain the relative robust multiplicator.
%		So there are always three columns (one for each group) in the middle of the matrix.
%       The last column contains the relative multiplicator of the current ray.

    % Check constraints
    if ~isfield(model, 'cM')
        model.cM = [];
    end
    if ~isfield(model, 'cB')
        model.cB = [];
    end

	[origSol] = solveLPProblem(-1, model.c, model.cM, model.cB, model.S, model.b, model.lb, model.ub);

    if (nargin > 6) && relative
        normBoundary = norm(origSol) * normBoundary / 100;
        diffSol = abs(origSol);
        diffSol(diffSol == 0) = 1;
        singleBoundary = diffSol * singleBoundary / 100;
    end
    
    % Set single boundaries
    if length(singleBoundary) ~= length(origSol)
        singleBoundary = ones(length(origSol), 1) .* singleBoundary;
    end
   
    if any(model.ub < model.lb)
        error('ROBUSTRANGETRIPLE:BoundaryCheck', 'Problem is infeasible. Please check your boundary conditions.');
    end
    
	nomVal = getModelCoefficients(model, groups);
    vals = zeros(angPerHalfCircle * (angPerHalfCircle - 1) * 2, length(nomVal) + 3);
    relVals = zeros(angPerHalfCircle * (angPerHalfCircle - 1) * 2, 7);
    phi = linspace(-pi / 2, pi / 2, angPerHalfCircle);
    theta = linspace(0, 2 * pi, 2 * angPerHalfCircle);
    theta = theta(1:end-1);
    
    for i = 1:length(theta)
%    parfor i = 1:length(theta)
        for j = 1:length(phi)
		    dir = [cos(phi(j)) * cos(theta(i)); cos(phi(j)) * sin(theta(i)); sin(phi(j))];

			[resLine, objVal, relLine, multi] = getRobustExtremeConstrainedFlux(dir, nomVal, origSol, model, groups, normBoundary, singleBoundary, maxIter);
        	vals(((i-1) * length(phi))+j, :) = [theta(i), phi(j), resLine', objVal];
            relVals(((i-1) * length(phi))+j, :) = [theta(i), phi(j), relLine', objVal, multi];
        end
    end
    
    if nargout > 1
        metNames = {};
        for i = 1:length(groups)
            metNames = [metNames model.mets(groups{i}.row)'];
        end
        table = [[{'theta'}, {'phi'}, metNames , {'objVal'}] ; num2cell(vals)];
    end
end

function val = getRobustExtreme(dir, vNom, model, groups, normBound, singleBoundary, maxIter)

    state = 1;
    iter = 0;
    nomVal = [full(model.S(groups{1}.row, groups{1}.column)); ...
        full(model.S(groups{2}.row, groups{2}.column)); ...
        full(model.S(groups{3}.row, groups{3}.column))];
    nomFac = norm(nomVal);
    if nomFac == 0
        nomFac = 1;
    end
    
    dir = [cos(dir(2)) * cos(dir(1)); cos(dir(2)) * sin(dir(1)); sin(dir(2))];
    
    veryLastVal = nomVal;
    lastVal = nomVal;
    curVal = nomVal + dir * nomFac * 0.5;
    while (iter <= maxIter)
        % Do a step
        curS = model.S;
        curS(groups{1}.row, groups{1}.column) = curVal(1); 
        curS(groups{2}.row, groups{2}.column) = curVal(2); 
        curS(groups{3}.row, groups{3}.column) = curVal(3); 
        
%        fprintf('%3g : % 14.12f  % 14.12f  % 14.12f\n', iter, curVal, lastVal, veryLastVal);
        
    	[sol, objVal] = solveLPProblem(-1, model.c, model.cM, model.cB, curS, model.b, model.lb, model.ub);
        
        % Check conditions
        if isnan(objVal) || (norm(vNom - sol) > normBound) || any(abs(vNom - sol) > singleBoundary)
            % Infeasible: We've gone too far
            if state == 1
                state = 2;
                veryLastVal = lastVal;
                lastVal = curVal;
                curVal = (lastVal + curVal) ./ 2;
            else
                lastVal = curVal;
                curVal = (curVal + veryLastVal) ./ 2;
            end
        else
            % Still valid: Push to the boundary
            if state == 1
                veryLastVal = lastVal;
                lastVal = curVal;
                curVal = curVal + 0.5 * nomFac * dir;
            else
                veryLastVal = curVal;
                curVal = (curVal + lastVal) ./ 2;
            end
        end
        
        iter = iter + 1;
    end
    if state == 1 
        val = [dir * inf; objVal];
    else
        val = [curVal; objVal];
    end
end
