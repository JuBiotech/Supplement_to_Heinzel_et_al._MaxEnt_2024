function [ minVal, maxVal, relVals ] = robustRangeSingle( model, group, normBoundary, singleBoundary, maxIter )
%ROBUSTRANGESINGLE Calculates the robust coefficient range of the given coefficient group.
% Computes the robust interval (min, max) of the given coefficient. A robust extreme, which forms the
% endpoint of a robust interval, is the maximum / minimum coefficient value for which the optimal solution
% of the FBA problem subject to the modified coefficient suffices the following conditions:
%	norm(v_nom - v_sol) <= normBoundary  and  abs(v_nom - v_sol) <= singleBoundary
%
% See getRobustExtremeConstrainedFlux for a description of the method used.
%
% Parameters:
%	- model: Model.
%	- group: Group structure. See MCGroups for hints.
%	- normBoundary: Upper bound on the solution deviation in the norm.
%	- singleBoundary: Upper bound on the absolute flux vector component deviation.
%	- maxIter: Maximum number of iterations. See getRobustExtremeConstrainedFlux for hints.
%
% Returns:
%	- minVal: Minimum robust flux coefficient values.
%	- maxVal: Maximum robust flux coefficient values.
%	- relVals: Vector with min and max relative robust multiplicator. See getRobustExtremeConstrainedFlux. 

    % Check constraints
    if ~isfield(model, 'cM')
        model.cM = [];
    end
    if ~isfield(model, 'cB')
        model.cB = [];
    end

	[origSol] = solveLPProblem(-1, model.c, model.cM, model.cB, model.S, model.b, model.lb, model.ub);

    % Set single boundaries
    if length(singleBoundary) ~= length(origSol)
        singleBoundary = ones(length(origSol), 1) .* singleBoundary;
    end
        
    if any(model.ub < model.lb)
        error('ROBUSTRANGESINGLE:BoundaryCheck', 'Problem is infeasible. Please check your boundary conditions.');
    end
    
    relVals = zeros(2,1);
	nomVal = getModelCoefficients(model, group);
	[minVal, temp, relVals(1)] = getRobustExtremeConstrainedFlux(-1, nomVal, origSol, model, group, normBoundary, singleBoundary, maxIter);
	[maxVal, temp, relVals(2)] = getRobustExtremeConstrainedFlux(1, nomVal, origSol, model, group, normBoundary, singleBoundary, maxIter);
end

function val = getRobustExtreme(dir, vNom, model, group, normBound, singleBoundary, maxIter)

    state = 1;
    iter = 0;
    nomVal = full(model.S(group.row, group.column));
    nomFac = abs(nomVal);
    if nomFac == 0
        nomFac = 1;
    end
    
    veryLastVal = nomVal;
    lastVal = nomVal;
    curVal = nomVal + dir * nomFac * 0.5;
    while (iter <= maxIter)
        % Do a step
        curS = model.S;
        curS(group.row, group.column) = curVal; 
        
%        fprintf('%3g : % 14.12f  % 14.12f  % 14.12f\n', iter, curVal, lastVal, veryLastVal);
        
    	[sol, objVal] = solveLPProblem(-1, model.c, model.cM, model.cB, curS, model.b, model.lb, model.ub);
        
        % Check conditions
        if isnan(objVal) || (norm(vNom - sol) > normBound) || any(abs(vNom - sol) > singleBoundary)
            % Infeasible: We've gone too far
            if state == 1
                state = 2;
                veryLastVal = lastVal;
                lastVal = curVal;
                curVal = (lastVal + curVal) / 2;
            else
                lastVal = curVal;
                curVal = (curVal + veryLastVal) / 2;
            end
        else
            % Still valid: Push to the boundary
            if state == 1
                veryLastVal = lastVal;
                lastVal = curVal;
                curVal = curVal + 0.5 * nomFac * dir;
            else
                veryLastVal = curVal;
                curVal = (curVal + lastVal) / 2;
            end
        end
        
        iter = iter + 1;
    end
    if state == 1 
        val = dir * inf;
    else
        val = curVal;
    end
end
